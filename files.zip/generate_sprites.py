#!/usr/bin/env python3
"""
Magic Baser - Complete Pixel Art Sprite Generator
Generates all game sprites: characters, mobs, tiles, decorations, effects, UI
"""

from PIL import Image, ImageDraw
import os
import random
import math

random.seed(42)  # reproducible

OUT = '/home/claude/sprites'

# ============================================================
# HELPERS
# ============================================================

T = (0, 0, 0, 0)  # transparent
BLK = (0, 0, 0, 255)
WHT = (255, 255, 255, 255)

def new(w, h):
    return Image.new('RGBA', (w, h), T)

def save(img, *parts):
    fp = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    img.save(fp)
    print(f"  ✓ {'/'.join(parts)}")

def px(img, x, y, c):
    if 0 <= x < img.width and 0 <= y < img.height and c[3] > 0:
        img.putpixel((x, y), c)

def rect(img, x, y, w, h, c):
    for dy in range(h):
        for dx in range(w):
            px(img, x+dx, y+dy, c)

def hline(img, y, x1, x2, c):
    for x in range(x1, x2+1):
        px(img, x, y, c)

def vline(img, x, y1, y2, c):
    for y in range(y1, y2+1):
        px(img, x, y, c)

def ellipse(img, cx, cy, rx, ry, c):
    for y in range(cy-ry, cy+ry+1):
        for x in range(cx-rx, cx+rx+1):
            dx, dy = x-cx, y-cy
            if rx > 0 and ry > 0 and (dx*dx)/(rx*rx) + (dy*dy)/(ry*ry) <= 1.0:
                px(img, x, y, c)

def outline(img, c=BLK):
    w, h = img.size
    p = img.load()
    pts = []
    for y in range(h):
        for x in range(w):
            if p[x, y][3] == 0:
                for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nx, ny = x+dx, y+dy
                    if 0 <= nx < w and 0 <= ny < h and p[nx, ny][3] > 0:
                        pts.append((x, y))
                        break
    for x, y in pts:
        p[x, y] = c

def dark(c, f=0.65):
    return (int(c[0]*f), int(c[1]*f), int(c[2]*f), c[3])

def lit(c, f=1.35):
    return (min(255,int(c[0]*f)), min(255,int(c[1]*f)), min(255,int(c[2]*f)), c[3])

def alpha(c, a):
    return (c[0], c[1], c[2], a)

# ============================================================
# COLOR PALETTE
# ============================================================

SKIN = (255, 204, 153, 255)
SKIN_S = (221, 170, 119, 255)
EYE = (34, 34, 68, 255)

RED = (204, 51, 51, 255)
DRED = (139, 34, 34, 255)
ORANGE = (255, 136, 0, 255)
YELLOW = (255, 221, 0, 255)
GOLD = (255, 204, 0, 255)

BLUE = (51, 102, 204, 255)
DBLUE = (34, 68, 153, 255)
ICE = (153, 210, 255, 255)
LICE = (200, 235, 255, 255)

GREEN = (51, 153, 51, 255)
DGREEN = (34, 102, 34, 255)
LGREEN = (120, 200, 120, 255)
LEAF = (100, 200, 60, 255)

PURPLE = (120, 60, 180, 255)
DPURPLE = (80, 40, 120, 255)
LPURPLE = (170, 120, 220, 255)

SHADOW = (60, 40, 80, 255)
DSHADOW = (40, 25, 55, 255)

DGRAY = (60, 60, 70, 255)
GRAY = (120, 120, 130, 255)
LGRAY = (170, 170, 180, 255)

BROWN = (136, 102, 51, 255)
DBROWN = (85, 60, 30, 255)
LBROWN = (170, 136, 85, 255)

BONE = (230, 215, 190, 255)
DBONE = (190, 175, 150, 255)

TEAL = (0, 180, 170, 255)
PINK = (220, 100, 150, 255)

POISON = (120, 200, 50, 255)
DPOISON = (80, 140, 30, 255)

NECRO_GREEN = (60, 120, 60, 255)
NECRO_DGREEN = (40, 80, 40, 255)

RUNE_BLUE = (40, 50, 120, 255)
RUNE_GLOW = (100, 140, 255, 255)

WHITE_ROBE = (230, 225, 215, 255)
GOLD_ROBE = (220, 190, 100, 255)

# ============================================================
# WIZARDS (32x32)
# ============================================================

def make_wizard(*, hat_fn, robe, belt, shoe, staff_gem=None, staff_wood=BROWN, special=None):
    img = new(32, 32)
    rl, rd = lit(robe), dark(robe)
    
    # -- HAT --
    hat_fn(img)
    
    # -- FACE (y=11..15) --
    rect(img, 11, 11, 10, 5, SKIN)
    # Eyes
    px(img, 13, 12, WHT); px(img, 18, 12, WHT)
    px(img, 13, 13, EYE); px(img, 18, 13, EYE)
    # Blush
    px(img, 12, 14, SKIN_S); px(img, 19, 14, SKIN_S)
    # Mouth
    px(img, 15, 14, SKIN_S); px(img, 16, 14, SKIN_S)
    
    # -- ROBE --
    rect(img, 11, 16, 10, 1, robe)   # collar
    rect(img, 10, 17, 12, 1, robe)   # upper shoulders
    rect(img, 9, 18, 14, 2, robe)    # shoulders
    hline(img, 20, 9, 22, belt)      # belt
    rect(img, 8, 21, 16, 3, robe)    # mid
    rect(img, 9, 24, 14, 2, robe)    # lower
    rect(img, 10, 26, 12, 1, robe)   # hem
    
    # Shading
    for y in range(18, 27):
        if 8 <= 8 < img.width:
            c = img.getpixel((9, y))
            if c[3] > 0:
                px(img, 8, y, rd)
                px(img, 9, y, rd)
        c2 = img.getpixel((22, y)) if 22 < img.width else T
        if c2[3] > 0:
            px(img, 22, y, rl)
            px(img, 23, y, rl)
    
    # -- FEET --
    rect(img, 11, 27, 3, 2, shoe)
    rect(img, 18, 27, 3, 2, shoe)
    
    # -- STAFF --
    if staff_gem:
        sx = 25
        vline(img, sx, 9, 26, staff_wood)
        rect(img, sx-1, 7, 3, 3, staff_gem)
        px(img, sx, 8, lit(staff_gem))
    
    # -- SPECIAL --
    if special:
        special(img)
    
    outline(img)
    return img


def hat_pointed(color, accent):
    def draw(img):
        for i in range(7):
            hline(img, 4+i, 15-i, 15+i, color)
        hline(img, 10, 9, 21, dark(color))
        hline(img, 11, 10, 20, dark(color))
        hline(img, 7, 12, 18, accent)
    return draw

def hat_crown(color, accent):
    def draw(img):
        rect(img, 10, 6, 12, 4, color)
        rect(img, 11, 5, 10, 1, color)
        # Spikes
        rect(img, 11, 3, 2, 3, lit(color))
        rect(img, 15, 2, 2, 4, lit(color))
        rect(img, 19, 3, 2, 3, lit(color))
        # Gems
        px(img, 12, 7, accent); px(img, 16, 7, accent); px(img, 20, 7, accent)
    return draw

def hat_wide(color, accent):
    def draw(img):
        for i in range(5):
            hline(img, 4+i, 14-i, 16+i, color)
        rect(img, 7, 9, 18, 2, color)
        hline(img, 8, 6, 25, dark(color))
        # Leaf
        px(img, 22, 6, accent); px(img, 23, 5, accent)
        px(img, 24, 6, accent); px(img, 23, 7, accent)
    return draw

def hat_hood(color, accent):
    def draw(img):
        rect(img, 9, 4, 14, 7, color)
        rect(img, 10, 3, 12, 1, color)
        rect(img, 11, 2, 10, 1, dark(color))
        # Shadow inside hood
        hline(img, 9, 10, 21, dark(color))
        hline(img, 10, 9, 22, dark(color, 0.5))
        # Hood draping on sides
        vline(img, 9, 8, 14, color)
        vline(img, 22, 8, 14, color)
    return draw

def hat_starhat(color, accent):
    def draw(img):
        for i in range(7):
            hline(img, 4+i, 15-i, 15+i, color)
        hline(img, 10, 9, 21, dark(color))
        hline(img, 11, 10, 20, dark(color))
        # Star emblem
        px(img, 15, 4, accent)
        px(img, 14, 5, accent); px(img, 15, 5, accent); px(img, 16, 5, accent)
        px(img, 15, 6, accent)
        px(img, 13, 5, accent); px(img, 17, 5, accent)
    return draw

def hat_skull(color, accent):
    def draw(img):
        rect(img, 10, 3, 12, 7, color)
        rect(img, 11, 2, 10, 1, color)
        # Eye holes
        rect(img, 12, 5, 3, 2, dark(color, 0.3))
        rect(img, 17, 5, 3, 2, dark(color, 0.3))
        # Nose
        px(img, 15, 7, dark(color, 0.3)); px(img, 16, 7, dark(color, 0.3))
        # Teeth
        for i in range(6):
            if i % 2 == 0:
                px(img, 12+i, 9, accent)
    return draw

def hat_halo(color, accent):
    def draw(img):
        # Hair/head cover
        rect(img, 10, 5, 12, 6, color)
        rect(img, 11, 4, 10, 1, color)
        # Halo ring above
        hline(img, 1, 11, 20, accent)
        px(img, 10, 2, accent); px(img, 21, 2, accent)
        hline(img, 3, 11, 20, accent)
        # Glow pixels
        px(img, 12, 2, lit(accent)); px(img, 19, 2, lit(accent))
    return draw

def hat_circlet(color, accent):
    def draw(img):
        # Hair
        rect(img, 10, 4, 12, 7, color)
        rect(img, 11, 3, 10, 1, color)
        # Circlet band
        hline(img, 9, 10, 21, accent)
        # Rune gems
        px(img, 12, 9, lit(accent))
        px(img, 16, 9, lit(accent))
        px(img, 20, 9, lit(accent))
    return draw


def generate_wizards():
    print("\n🧙 Generating Wizards...")
    
    # 1. Ignis - Fire Mage
    def ignis_flame(img):
        px(img, 15, 1, YELLOW)
        px(img, 14, 2, ORANGE); px(img, 15, 2, YELLOW); px(img, 16, 2, ORANGE)
        px(img, 15, 3, ORANGE)
    
    save(make_wizard(
        hat_fn=hat_pointed(RED, ORANGE),
        robe=RED, belt=DRED, shoe=DBROWN,
        staff_gem=ORANGE, special=ignis_flame
    ), 'characters', 'ignis.png')
    
    # 2. Gleisha - Ice Mage
    save(make_wizard(
        hat_fn=hat_crown(ICE, (100, 200, 255, 255)),
        robe=BLUE, belt=DBLUE, shoe=DBROWN,
        staff_gem=ICE
    ), 'characters', 'gleisha.png')
    
    # 3. Vitalis - Nature Mage
    save(make_wizard(
        hat_fn=hat_wide(GREEN, LEAF),
        robe=GREEN, belt=DGREEN, shoe=DBROWN,
        staff_gem=LEAF
    ), 'characters', 'vitalis.png')
    
    # 4. Umbra - Shadow Mage
    def umbra_shadow(img):
        # Shadow wisps around feet
        px(img, 9, 28, alpha(DSHADOW, 150))
        px(img, 22, 28, alpha(DSHADOW, 150))
        px(img, 8, 27, alpha(DSHADOW, 100))
        px(img, 23, 27, alpha(DSHADOW, 100))
    
    save(make_wizard(
        hat_fn=hat_hood(SHADOW, DSHADOW),
        robe=SHADOW, belt=DSHADOW, shoe=(30, 20, 40, 255),
        staff_gem=LPURPLE, special=umbra_shadow
    ), 'characters', 'umbra.png')
    
    # 5. Archon - Arcane Mage
    def archon_book(img):
        # Floating book on left side
        rect(img, 3, 16, 4, 5, DPURPLE)
        rect(img, 4, 17, 2, 3, LPURPLE)
        px(img, 5, 18, WHT)  # page
    
    save(make_wizard(
        hat_fn=hat_starhat(PURPLE, GOLD),
        robe=PURPLE, belt=DPURPLE, shoe=DBROWN,
        staff_gem=GOLD, special=archon_book
    ), 'characters', 'archon.png')
    
    # 6. Nektra - Death Mage
    save(make_wizard(
        hat_fn=hat_skull(BONE, WHT),
        robe=NECRO_GREEN, belt=NECRO_DGREEN, shoe=DBROWN,
        staff_gem=(200, 255, 200, 255), staff_wood=DBONE
    ), 'characters', 'nektra.png')
    
    # 7. Lumen - Light Mage
    def lumen_glow(img):
        # Light particles
        px(img, 7, 12, alpha(GOLD, 150))
        px(img, 24, 15, alpha(GOLD, 150))
        px(img, 6, 20, alpha(GOLD, 100))
        px(img, 26, 22, alpha(GOLD, 100))
    
    save(make_wizard(
        hat_fn=hat_halo(WHITE_ROBE, GOLD),
        robe=WHITE_ROBE, belt=GOLD_ROBE, shoe=LBROWN,
        staff_gem=GOLD, special=lumen_glow
    ), 'characters', 'lumen.png')
    
    # 8. Runika - Rune Mage
    def runika_runes(img):
        # Glowing runes on robe
        px(img, 12, 22, RUNE_GLOW)
        px(img, 16, 21, RUNE_GLOW)
        px(img, 19, 23, RUNE_GLOW)
        px(img, 14, 24, RUNE_GLOW)
    
    save(make_wizard(
        hat_fn=hat_circlet(RUNE_BLUE, RUNE_GLOW),
        robe=RUNE_BLUE, belt=dark(RUNE_BLUE), shoe=DBROWN,
        staff_gem=RUNE_GLOW, staff_wood=dark(BROWN),
        special=runika_runes
    ), 'characters', 'runika.png')


# ============================================================
# MOBS
# ============================================================

def make_skeleton():
    """Skeleton - 24x24, white bones, red eyes"""
    img = new(24, 24)
    # Skull
    rect(img, 8, 1, 8, 7, BONE)
    rect(img, 9, 0, 6, 1, BONE)
    # Eye sockets
    rect(img, 9, 3, 2, 2, BLK)
    rect(img, 13, 3, 2, 2, BLK)
    px(img, 9, 3, (255, 50, 50, 255))  # red eye
    px(img, 13, 3, (255, 50, 50, 255))
    # Teeth
    hline(img, 6, 10, 13, DBONE)
    px(img, 10, 7, BONE); px(img, 12, 7, BONE)
    # Spine
    vline(img, 11, 8, 10, BONE)
    vline(img, 12, 8, 10, BONE)
    # Ribcage
    for i in range(3):
        hline(img, 11+i, 8, 15, DBONE)
        px(img, 9+i, 11+i, BONE)
        px(img, 14-i, 11+i, BONE)
    # Arms
    hline(img, 11, 5, 7, BONE)
    hline(img, 11, 16, 18, BONE)
    vline(img, 5, 12, 15, BONE)
    vline(img, 18, 12, 15, BONE)
    # Pelvis
    rect(img, 9, 14, 6, 2, DBONE)
    # Legs
    vline(img, 9, 16, 21, BONE)
    vline(img, 14, 16, 21, BONE)
    # Feet
    hline(img, 22, 8, 10, BONE)
    hline(img, 22, 13, 15, BONE)
    
    outline(img)
    return img

def make_zombie():
    """Zombie - 24x24, green, hunched"""
    img = new(24, 24)
    zg = (100, 160, 80, 255)  # zombie green
    zd = (70, 120, 55, 255)   # dark green
    cloth = (100, 80, 60, 255)  # torn cloth
    
    # Head (slightly tilted/hunched)
    rect(img, 8, 2, 8, 7, zg)
    rect(img, 9, 1, 6, 1, zg)
    # Eyes (uneven)
    px(img, 10, 4, (200, 200, 50, 255))  # yellow eye
    px(img, 14, 5, (200, 200, 50, 255))  # offset eye
    # Mouth
    hline(img, 7, 10, 14, zd)
    # Body (hunched forward)
    rect(img, 7, 9, 10, 3, cloth)
    rect(img, 6, 12, 12, 4, cloth)
    # Torn edges
    px(img, 6, 15, T); px(img, 8, 15, T); px(img, 16, 14, T)
    # Arms (reaching forward)
    rect(img, 3, 10, 4, 2, zg)
    rect(img, 1, 10, 2, 2, zg)
    rect(img, 17, 10, 4, 2, zg)
    rect(img, 20, 9, 2, 2, zg)
    # Legs
    rect(img, 8, 16, 3, 5, zg)
    rect(img, 13, 16, 3, 5, zg)
    # Feet
    rect(img, 7, 21, 4, 2, zd)
    rect(img, 13, 21, 4, 2, zd)
    # Skin patches/wounds
    px(img, 9, 5, zd); px(img, 7, 13, zd)
    
    outline(img)
    return img

def make_bat():
    """Bat - 16x16, purple, spread wings"""
    img = new(16, 16)
    bc = (120, 60, 140, 255)   # body purple
    bw = (100, 50, 120, 255)   # wing darker
    bd = (80, 40, 100, 255)    # wing darkest
    
    # Body (small, center)
    rect(img, 6, 6, 4, 4, bc)
    rect(img, 7, 5, 2, 1, bc)
    # Ears
    px(img, 6, 4, bc); px(img, 9, 4, bc)
    px(img, 6, 3, bc); px(img, 9, 3, bc)
    # Eyes (red)
    px(img, 7, 6, (255, 50, 50, 255))
    px(img, 8, 6, (255, 50, 50, 255))
    # Fangs
    px(img, 7, 9, WHT)
    px(img, 8, 9, WHT)
    # Left wing
    rect(img, 1, 5, 5, 4, bw)
    px(img, 0, 4, bw); px(img, 2, 4, bw)
    px(img, 1, 9, bd); px(img, 3, 9, bd)
    px(img, 0, 8, T); px(img, 0, 9, T)
    # Right wing
    rect(img, 10, 5, 5, 4, bw)
    px(img, 15, 4, bw); px(img, 13, 4, bw)
    px(img, 12, 9, bd); px(img, 14, 9, bd)
    px(img, 15, 8, T); px(img, 15, 9, T)
    # Wing membrane details
    px(img, 2, 7, bd); px(img, 13, 7, bd)
    # Small feet
    px(img, 7, 10, bd); px(img, 8, 10, bd)
    
    outline(img)
    return img

def make_ghost():
    """Ghost - 24x24, white, floating, wavy bottom"""
    img = new(24, 24)
    gc = (220, 225, 240, 200)   # ghost white (semi-transparent)
    gd = (180, 185, 200, 180)   # ghost shadow
    gl = (240, 245, 255, 220)   # ghost highlight
    
    # Head (round)
    ellipse(img, 11, 6, 5, 5, gc)
    # Highlight
    px(img, 9, 4, gl); px(img, 10, 4, gl)
    # Eyes (empty dark sockets)
    rect(img, 8, 5, 3, 3, (30, 30, 60, 255))
    rect(img, 13, 5, 3, 3, (30, 30, 60, 255))
    # Pupil glow
    px(img, 9, 6, (150, 150, 255, 255))
    px(img, 14, 6, (150, 150, 255, 255))
    # Mouth (O shape)
    rect(img, 10, 9, 4, 2, (30, 30, 60, 200))
    # Body (flowing down, widening)
    rect(img, 7, 11, 10, 4, gc)
    rect(img, 6, 15, 12, 3, gc)
    rect(img, 5, 18, 14, 2, gd)
    # Wavy bottom
    px(img, 5, 20, gd); px(img, 7, 20, gc); px(img, 9, 21, gd)
    px(img, 11, 20, gc); px(img, 13, 21, gd); px(img, 15, 20, gc)
    px(img, 17, 20, gd); px(img, 18, 20, gd)
    # Arms (wispy)
    rect(img, 3, 13, 3, 2, gd)
    rect(img, 18, 13, 3, 2, gd)
    px(img, 2, 14, gd); px(img, 21, 14, gd)
    
    outline(img, (80, 80, 120, 255))  # softer outline for ghost
    return img

def make_spider():
    """Spider - 12x12, brown, multiple legs"""
    img = new(12, 12)
    sb = (80, 50, 30, 255)    # body brown
    sl = (50, 30, 15, 255)    # leg dark
    
    # Body (2 segments)
    rect(img, 4, 3, 4, 3, sb)     # cephalothorax
    rect(img, 4, 6, 5, 4, dark(sb))  # abdomen
    # Eyes (cluster of red dots)
    px(img, 5, 3, (255, 30, 30, 255))
    px(img, 7, 3, (255, 30, 30, 255))
    px(img, 4, 3, (200, 30, 30, 255))
    px(img, 8, 3, (200, 30, 30, 255))
    # Pedipalps
    px(img, 4, 2, sl); px(img, 8, 2, sl)
    # Legs (4 on each side)
    # Left legs
    px(img, 3, 3, sl); px(img, 2, 2, sl)  # front left
    px(img, 3, 4, sl); px(img, 2, 5, sl); px(img, 1, 6, sl)
    px(img, 3, 5, sl); px(img, 2, 6, sl); px(img, 1, 7, sl)
    px(img, 3, 7, sl); px(img, 2, 8, sl)  # back left
    # Right legs
    px(img, 9, 3, sl); px(img, 10, 2, sl)
    px(img, 9, 4, sl); px(img, 10, 5, sl); px(img, 11, 6, sl)
    px(img, 9, 5, sl); px(img, 10, 6, sl); px(img, 11, 7, sl)
    px(img, 9, 7, sl); px(img, 10, 8, sl)
    # Abdomen pattern
    px(img, 6, 7, lit(sb)); px(img, 6, 9, lit(sb))
    
    outline(img)
    return img

def make_dark_mage():
    """Dark Mage - 28x28, ranged enemy, dark robe red eyes"""
    img = new(28, 28)
    dc = (50, 30, 50, 255)    # dark robe
    dl = (70, 45, 70, 255)    # dark robe light
    dr = (35, 20, 35, 255)    # dark robe dark
    
    # Hood (large, ominous)
    rect(img, 8, 1, 12, 8, dc)
    rect(img, 9, 0, 10, 1, dc)
    rect(img, 7, 4, 1, 5, dc)
    rect(img, 20, 4, 1, 5, dc)
    # Hood interior (dark)
    rect(img, 9, 3, 10, 5, dr)
    # Eyes (glowing red in darkness)
    px(img, 11, 5, (255, 50, 30, 255))
    px(img, 16, 5, (255, 50, 30, 255))
    px(img, 11, 4, (255, 100, 50, 200))  # glow
    px(img, 16, 4, (255, 100, 50, 200))
    # Body robe
    rect(img, 8, 9, 12, 3, dc)
    rect(img, 7, 12, 14, 4, dc)
    rect(img, 6, 16, 16, 4, dc)
    rect(img, 7, 20, 14, 3, dc)
    rect(img, 8, 23, 12, 2, dc)
    # Robe highlights
    vline(img, 8, 12, 22, dl)
    vline(img, 19, 12, 22, dl)
    # Skeletal hands
    rect(img, 3, 12, 3, 2, BONE)
    px(img, 2, 13, BONE); px(img, 2, 14, BONE)
    rect(img, 22, 12, 3, 2, BONE)
    px(img, 25, 13, BONE); px(img, 25, 14, BONE)
    # Dark orb in right hand
    ellipse(img, 24, 11, 2, 2, (150, 50, 200, 255))
    px(img, 24, 11, (200, 100, 255, 255))
    # Tattered bottom
    px(img, 8, 24, T); px(img, 10, 24, T)
    px(img, 17, 24, T); px(img, 19, 24, T)
    # Feet hidden
    
    outline(img)
    return img

def make_golem():
    """Golem - 48x48, big stone creature"""
    img = new(48, 48)
    gs = (100, 100, 110, 255)   # stone
    gd = (70, 70, 80, 255)      # stone dark
    gl = (140, 140, 150, 255)   # stone light
    gc = (60, 55, 50, 255)      # cracks
    
    # Head (blocky, small relative to body)
    rect(img, 17, 2, 14, 10, gs)
    rect(img, 18, 1, 12, 1, gs)
    # Eyes (glowing yellow)
    rect(img, 20, 5, 3, 3, (255, 200, 50, 255))
    rect(img, 27, 5, 3, 3, (255, 200, 50, 255))
    px(img, 21, 6, (255, 255, 150, 255))
    px(img, 28, 6, (255, 255, 150, 255))
    # Jaw
    rect(img, 19, 9, 10, 3, gd)
    for i in range(4):
        px(img, 20+i*2, 11, gs)  # teeth
    
    # Massive shoulders/body
    rect(img, 8, 12, 32, 6, gs)
    rect(img, 6, 18, 36, 10, gs)
    rect(img, 8, 28, 32, 6, gs)
    rect(img, 10, 34, 28, 4, gs)
    
    # Arms (thick)
    rect(img, 2, 14, 6, 16, gs)
    rect(img, 0, 18, 3, 8, gs)   # left fist
    rect(img, 40, 14, 6, 16, gs)
    rect(img, 45, 18, 3, 8, gs)  # right fist
    
    # Legs
    rect(img, 12, 38, 8, 8, gs)
    rect(img, 28, 38, 8, 8, gs)
    rect(img, 10, 44, 10, 3, gd)  # feet
    rect(img, 27, 44, 10, 3, gd)
    
    # Cracks and detail
    vline(img, 22, 14, 22, gc)
    hline(img, 20, 15, 25, gc)
    px(img, 18, 25, gc); px(img, 30, 18, gc)
    vline(img, 35, 22, 28, gc)
    hline(img, 26, 10, 16, gc)
    
    # Stone texture (lighter patches)
    for _ in range(20):
        rx = random.randint(8, 38)
        ry = random.randint(14, 36)
        if img.getpixel((rx, ry))[3] > 0:
            px(img, rx, ry, gl)
    
    # Darker patches  
    for _ in range(15):
        rx = random.randint(8, 38)
        ry = random.randint(14, 36)
        if img.getpixel((rx, ry))[3] > 0:
            px(img, rx, ry, gd)
    
    # Mossy patches
    moss = (80, 120, 70, 255)
    for _ in range(8):
        rx = random.randint(8, 38)
        ry = random.randint(24, 36)
        if img.getpixel((rx, ry))[3] > 0:
            px(img, rx, ry, moss)
    
    outline(img)
    return img

def make_necromorph():
    """Necromorph - 40x40, floating necromancer mini-boss"""
    img = new(40, 40)
    nc = (40, 60, 40, 255)     # robe
    nl = (60, 90, 60, 255)     # robe light
    nd = (25, 40, 25, 255)     # robe dark
    glow = (100, 255, 100, 200)  # green glow
    
    # Skull head
    rect(img, 14, 2, 12, 10, BONE)
    rect(img, 15, 1, 10, 1, BONE)
    rect(img, 15, 12, 10, 1, DBONE)
    # Eye sockets (green glow)
    rect(img, 16, 5, 3, 3, BLK)
    rect(img, 22, 5, 3, 3, BLK)
    px(img, 17, 6, glow)
    px(img, 23, 6, glow)
    # Nose
    px(img, 19, 8, (150, 130, 100, 255))
    px(img, 20, 8, (150, 130, 100, 255))
    # Jaw
    rect(img, 16, 10, 8, 2, DBONE)
    
    # Robe/body
    rect(img, 12, 13, 16, 4, nc)
    rect(img, 10, 17, 20, 5, nc)
    rect(img, 8, 22, 24, 5, nc)
    rect(img, 10, 27, 20, 3, nc)
    # Robe shading
    vline(img, 10, 18, 26, nd)
    vline(img, 11, 18, 26, nd)
    vline(img, 29, 18, 26, nl)
    vline(img, 28, 18, 26, nl)
    
    # Arms holding staff
    rect(img, 5, 17, 5, 3, nc)
    rect(img, 30, 17, 5, 3, nc)
    # Bony hands
    rect(img, 3, 18, 2, 2, BONE)
    rect(img, 35, 18, 2, 2, BONE)
    
    # Staff with skull
    vline(img, 36, 5, 30, DBROWN)
    rect(img, 34, 2, 5, 4, BONE)
    px(img, 35, 3, (100, 255, 100, 255))
    px(img, 37, 3, (100, 255, 100, 255))
    
    # Ghostly trail below (fading)
    for i in range(4):
        a = 150 - i * 35
        c = (40, 80, 40, max(0, a))
        hline(img, 30+i, 12+i, 28-i, c)
    
    # Green glow particles
    px(img, 13, 20, alpha(glow, 120))
    px(img, 27, 15, alpha(glow, 100))
    px(img, 8, 25, alpha(glow, 80))
    px(img, 32, 24, alpha(glow, 80))
    
    outline(img, (20, 40, 20, 255))
    return img

def make_dark_projectile():
    """Dark mage projectile - 8x8"""
    img = new(8, 8)
    ellipse(img, 3, 3, 3, 3, (150, 50, 200, 255))
    ellipse(img, 3, 3, 2, 2, (200, 100, 255, 255))
    px(img, 3, 3, (240, 180, 255, 255))
    outline(img)
    return img


def generate_mobs():
    print("\n👹 Generating Mobs...")
    save(make_skeleton(), 'mobs', 'skeleton.png')
    save(make_zombie(), 'mobs', 'zombie.png')
    save(make_bat(), 'mobs', 'bat.png')
    save(make_ghost(), 'mobs', 'ghost.png')
    save(make_spider(), 'mobs', 'spider.png')
    save(make_dark_mage(), 'mobs', 'dark_mage.png')
    save(make_golem(), 'mobs', 'golem.png')
    save(make_necromorph(), 'mobs', 'necromorph.png')
    save(make_dark_projectile(), 'mobs', 'dark_projectile.png')


# ============================================================
# FLOOR TILES (32x32)
# ============================================================

def make_floor_tile(base_color, variation=0):
    img = new(32, 32)
    bc = base_color
    
    for y in range(32):
        for x in range(32):
            # Base color with slight random variation
            r = bc[0] + random.randint(-8, 8)
            g = bc[1] + random.randint(-8, 8)
            b = bc[2] + random.randint(-8, 8)
            px(img, x, y, (max(0,min(255,r)), max(0,min(255,g)), max(0,min(255,b)), 255))
    
    # Tile border (subtle grid lines)
    for i in range(32):
        px(img, i, 0, dark(bc, 0.8))
        px(img, i, 31, dark(bc, 0.85))
        px(img, 0, i, dark(bc, 0.8))
        px(img, 31, i, dark(bc, 0.85))
    
    if variation == 1:
        # Add some cracks
        for i in range(5):
            cx = random.randint(5, 27)
            cy = random.randint(5, 27)
            for j in range(random.randint(3, 8)):
                px(img, cx+j, cy+random.randint(-1,1), dark(bc, 0.5))
    elif variation == 2:
        # Moss spots
        for _ in range(6):
            mx, my = random.randint(3, 28), random.randint(3, 28)
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    if random.random() > 0.3:
                        px(img, mx+dx, my+dy, (bc[0]-20, bc[1]+15, bc[2]-15, 255))
    elif variation == 3:
        # Wet/damp look
        for y in range(32):
            for x in range(32):
                if random.random() < 0.15:
                    c = img.getpixel((x, y))
                    px(img, x, y, (c[0]-5, c[1]-5, c[2]+10, 255))
    
    return img

def generate_tiles():
    print("\n🧱 Generating Tiles...")
    stone = (45, 42, 55, 255)
    stone_light = (55, 52, 65, 255)
    
    random.seed(42)
    save(make_floor_tile(stone, 0), 'tiles', 'floor_stone_1.png')
    random.seed(43)
    save(make_floor_tile(stone_light, 0), 'tiles', 'floor_stone_2.png')
    random.seed(44)
    save(make_floor_tile(stone, 1), 'tiles', 'floor_stone_3.png')       # with cracks
    random.seed(45)
    save(make_floor_tile(stone_light, 1), 'tiles', 'floor_stone_4.png') # with cracks
    random.seed(46)
    save(make_floor_tile(stone, 2), 'tiles', 'floor_stone_moss.png')    # mossy
    random.seed(47)
    save(make_floor_tile(stone, 3), 'tiles', 'floor_stone_wet.png')     # wet


# ============================================================
# DECORATIONS
# ============================================================

def make_barrel():
    """Barrel - 24x24"""
    img = new(24, 24)
    bw = (140, 100, 50, 255)   # wood
    bwd = (100, 70, 30, 255)   # wood dark
    bwl = (170, 130, 70, 255)  # wood light
    band = (80, 80, 90, 255)   # metal band
    
    # Barrel body (oval)
    for y in range(4, 22):
        # Width varies (wider in middle)
        t = (y - 4) / 17.0
        w = int(8 + 4 * math.sin(t * math.pi))
        cx = 12
        hline(img, y, cx-w, cx+w-1, bw)
    
    # Metal bands
    for y in [5, 12, 19]:
        for x in range(24):
            if img.getpixel((x, y))[3] > 0:
                px(img, x, y, band)
    
    # Wood grain (vertical lines)
    for x in [8, 12, 16]:
        for y in range(4, 22):
            if img.getpixel((x, y))[3] > 0:
                px(img, x, y, bwd)
    
    # Highlight (left side)
    for y in range(6, 20):
        if img.getpixel((8, y))[3] > 0:
            px(img, 7, y, bwl)
    
    # Top rim
    ellipse(img, 12, 4, 7, 2, bwd)
    ellipse(img, 12, 4, 6, 1, bwl)
    
    outline(img)
    return img

def make_barrel_cobweb():
    """Barrel with cobweb - 24x24"""
    img = make_barrel()
    # Remove outline temporarily
    cw = (200, 200, 210, 180)  # cobweb color
    # Add cobweb on top-right
    px(img, 18, 3, cw)
    px(img, 19, 2, cw); px(img, 20, 1, cw)
    px(img, 19, 4, cw); px(img, 20, 5, cw)
    px(img, 21, 2, cw); px(img, 21, 3, cw)
    px(img, 20, 3, cw)
    px(img, 22, 1, cw)
    return img

def make_barrel_broken():
    """Broken barrel - 24x24"""
    img = new(24, 24)
    bw = (140, 100, 50, 255)
    bwd = (100, 70, 30, 255)
    band = (80, 80, 90, 255)
    
    # Bottom half of barrel
    for y in range(14, 22):
        t = (y - 4) / 17.0
        w = int(8 + 4 * math.sin(t * math.pi))
        hline(img, y, 12-w, 12+w-1, bw)
    hline(img, 19, 5, 19, band)
    
    # Scattered planks
    rect(img, 3, 8, 2, 6, bwd)
    rect(img, 17, 6, 2, 5, bw)
    rect(img, 10, 10, 5, 2, bwd)
    
    # Splinters
    px(img, 8, 9, bw); px(img, 14, 7, bw)
    
    outline(img)
    return img

def make_column():
    """Stone column - 32x48"""
    img = new(32, 48)
    cs = (130, 130, 140, 255)
    cd = (90, 90, 100, 255)
    cl = (160, 160, 170, 255)
    
    # Capital (top, wider)
    rect(img, 6, 0, 20, 4, cs)
    rect(img, 7, 4, 18, 2, cl)
    
    # Shaft
    rect(img, 9, 6, 14, 34, cs)
    # Highlight
    rect(img, 10, 6, 3, 34, cl)
    # Shadow
    rect(img, 20, 6, 3, 34, cd)
    
    # Fluting (vertical lines)
    for y in range(6, 40):
        px(img, 13, y, cd)
        px(img, 17, y, cd)
    
    # Base (wider)
    rect(img, 7, 40, 18, 2, cl)
    rect(img, 6, 42, 20, 4, cs)
    rect(img, 5, 44, 22, 2, cd)
    
    # Weathering
    for _ in range(10):
        rx, ry = random.randint(9, 22), random.randint(8, 38)
        px(img, rx, ry, cd)
    
    outline(img)
    return img

def make_cracks(variant=0):
    """Floor cracks overlay - 32x32"""
    img = new(32, 32)
    cc = (30, 28, 35, 200)
    
    if variant == 0:
        # Diagonal crack
        for i in range(18):
            x = 8 + i
            y = 6 + i + random.randint(-1, 1)
            px(img, x, y, cc)
            if random.random() > 0.5:
                px(img, x+1, y, cc)
    elif variant == 1:
        # Star crack
        cx, cy = 16, 16
        for angle_i in range(5):
            angle = angle_i * 72 * math.pi / 180
            for r in range(2, 10):
                x = int(cx + r * math.cos(angle))
                y = int(cy + r * math.sin(angle))
                px(img, x, y, cc)
    elif variant == 2:
        # Small crack cluster
        cx, cy = 14, 14
        for i in range(8):
            px(img, cx+i, cy+random.randint(-1,1), cc)
        for i in range(5):
            px(img, cx+2+random.randint(-1,1), cy+i, cc)
    
    return img

def make_puddle(is_poison=False):
    """Puddle overlay - 32x32"""
    img = new(32, 32)
    if is_poison:
        pc = (80, 160, 40, 130)
        pl = (100, 200, 50, 100)
    else:
        pc = (40, 50, 80, 120)
        pl = (60, 70, 110, 90)
    
    ellipse(img, 16, 18, 8, 5, pc)
    ellipse(img, 14, 17, 5, 3, pl)
    # Shine
    px(img, 12, 16, (255, 255, 255, 60))
    px(img, 13, 16, (255, 255, 255, 40))
    
    return img

def make_moss():
    """Moss overlay - 32x32"""
    img = new(32, 32)
    colors = [
        (50, 100, 40, 180),
        (60, 120, 50, 160),
        (40, 90, 35, 140),
    ]
    
    for _ in range(15):
        x, y = random.randint(2, 29), random.randint(2, 29)
        c = random.choice(colors)
        px(img, x, y, c)
        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            if random.random() > 0.4:
                px(img, x+dx, y+dy, c)
    
    return img

def make_skull_decor():
    """Small skull decoration - 16x16"""
    img = new(16, 16)
    
    # Skull
    rect(img, 4, 2, 8, 7, BONE)
    rect(img, 5, 1, 6, 1, BONE)
    rect(img, 5, 9, 6, 1, DBONE)
    # Eye sockets
    rect(img, 5, 4, 2, 2, BLK)
    rect(img, 9, 4, 2, 2, BLK)
    # Nose
    px(img, 7, 6, DBONE); px(img, 8, 6, DBONE)
    # Teeth
    px(img, 6, 8, BONE); px(img, 8, 8, BONE); px(img, 10, 8, BONE)
    # Crossbones
    px(img, 3, 11, BONE); px(img, 4, 12, BONE); px(img, 5, 13, BONE)
    px(img, 11, 11, BONE); px(img, 10, 12, BONE); px(img, 9, 13, BONE)
    px(img, 3, 13, BONE); px(img, 4, 12, BONE); px(img, 5, 11, BONE)
    px(img, 11, 13, BONE); px(img, 10, 12, BONE); px(img, 9, 11, BONE)
    px(img, 6, 12, BONE); px(img, 7, 12, BONE); px(img, 8, 12, BONE)
    
    outline(img)
    return img

def make_torch():
    """Wall torch - 16x32, 4 animation frames"""
    frames = []
    for frame in range(4):
        img = new(16, 32)
        
        # Mount bracket
        rect(img, 6, 16, 4, 3, GRAY)
        px(img, 5, 17, GRAY)
        # Stick
        rect(img, 7, 8, 2, 8, DBROWN)
        # Flame base
        rect(img, 5, 5, 6, 4, ORANGE)
        rect(img, 6, 3, 4, 3, YELLOW)
        
        # Flame tip (animated)
        if frame == 0:
            rect(img, 7, 1, 2, 2, YELLOW)
            px(img, 7, 0, (255, 200, 100, 200))
        elif frame == 1:
            px(img, 6, 1, YELLOW); rect(img, 7, 0, 2, 2, YELLOW)
            px(img, 6, 0, (255, 200, 100, 200))
        elif frame == 2:
            rect(img, 7, 1, 2, 2, YELLOW)
            px(img, 8, 0, YELLOW)
            px(img, 9, 1, (255, 200, 100, 200))
        elif frame == 3:
            rect(img, 7, 1, 2, 3, YELLOW)
            px(img, 8, 0, (255, 200, 100, 200))
        
        # Glow
        px(img, 4, 6, alpha(ORANGE, 100))
        px(img, 11, 6, alpha(ORANGE, 100))
        
        outline(img)
        frames.append(img)
    return frames

def make_cobweb():
    """Cobweb overlay - 32x32 (corner cobweb)"""
    img = new(32, 32)
    cw = (200, 200, 210, 160)
    
    # Radial threads from top-left corner
    for angle_deg in range(0, 100, 15):
        angle = angle_deg * math.pi / 180
        for r in range(2, 20):
            x = int(r * math.cos(angle))
            y = int(r * math.sin(angle))
            if 0 <= x < 32 and 0 <= y < 32:
                px(img, x, y, cw)
    
    # Concentric arcs
    for radius in [6, 10, 14, 18]:
        for angle_deg in range(0, 95, 5):
            angle = angle_deg * math.pi / 180
            x = int(radius * math.cos(angle))
            y = int(radius * math.sin(angle))
            if 0 <= x < 32 and 0 <= y < 32:
                px(img, x, y, alpha(cw, 120))
    
    return img

def make_coffin():
    """Coffin - 24x40"""
    img = new(24, 40)
    wd = (70, 50, 35, 255)     # dark wood
    wl = (100, 75, 50, 255)    # wood
    band = (80, 80, 90, 255)
    
    # Coffin shape (hexagonal)
    for y in range(4, 38):
        if y < 10:
            hw = 4 + (y - 4)
        elif y < 30:
            hw = 10
        else:
            hw = 10 - (y - 30)
        hw = max(2, hw)
        hline(img, y, 12-hw, 12+hw-1, wl)
    
    # Wood grain
    for x in [8, 12, 16]:
        for y in range(4, 38):
            if img.getpixel((x, y))[3] > 0:
                px(img, x, y, wd)
    
    # Metal bands
    for y in [8, 20, 32]:
        for x in range(24):
            if img.getpixel((x, y))[3] > 0:
                px(img, x, y, band)
    
    # Cross on lid
    vline(img, 12, 12, 18, band)
    hline(img, 15, 10, 14, band)
    
    # Nails
    for y in [8, 20, 32]:
        px(img, 6, y, LGRAY) if img.getpixel((6, y))[3] > 0 else None
        px(img, 18, y, LGRAY) if img.getpixel((18, y))[3] > 0 else None
    
    outline(img)
    return img

def make_table():
    """Wooden table - 40x24"""
    img = new(40, 24)
    tw = (120, 85, 50, 255)
    td = (90, 60, 35, 255)
    tl = (150, 115, 70, 255)
    
    # Tabletop
    rect(img, 2, 4, 36, 4, tw)
    hline(img, 4, 2, 37, tl)  # top edge highlight
    hline(img, 7, 2, 37, td)  # bottom edge shadow
    
    # Legs
    rect(img, 4, 8, 3, 14, td)
    rect(img, 33, 8, 3, 14, td)
    # Cross brace
    hline(img, 15, 7, 33, td)
    
    # Surface detail
    for x in [10, 18, 26]:
        vline(img, x, 4, 7, td)
    
    # Items on table (optional)
    # Small book
    rect(img, 14, 1, 5, 3, DPURPLE)
    rect(img, 15, 2, 3, 1, WHT)
    # Candle
    rect(img, 28, 1, 2, 3, (200, 190, 160, 255))
    px(img, 28, 0, ORANGE); px(img, 29, 0, YELLOW)
    
    outline(img)
    return img


def generate_decorations():
    print("\n🏺 Generating Decorations...")
    save(make_barrel(), 'decorations', 'barrel.png')
    save(make_barrel_cobweb(), 'decorations', 'barrel_cobweb.png')
    save(make_barrel_broken(), 'decorations', 'barrel_broken.png')
    save(make_column(), 'decorations', 'column.png')
    save(make_coffin(), 'decorations', 'coffin.png')
    save(make_table(), 'decorations', 'table.png')
    save(make_skull_decor(), 'decorations', 'skull.png')
    save(make_cobweb(), 'decorations', 'cobweb.png')
    
    random.seed(50)
    save(make_cracks(0), 'decorations', 'cracks_1.png')
    save(make_cracks(1), 'decorations', 'cracks_2.png')
    save(make_cracks(2), 'decorations', 'cracks_3.png')
    
    save(make_puddle(False), 'decorations', 'puddle_water.png')
    save(make_puddle(True), 'decorations', 'puddle_poison.png')
    
    random.seed(55)
    save(make_moss(), 'decorations', 'moss_1.png')
    random.seed(56)
    save(make_moss(), 'decorations', 'moss_2.png')
    
    # Torch frames
    frames = make_torch()
    for i, f in enumerate(frames):
        save(f, 'decorations', f'torch_{i+1}.png')


# ============================================================
# EFFECTS
# ============================================================

def make_xp_gem():
    """XP gem - 8x8, green"""
    img = new(8, 8)
    gc = (50, 200, 50, 255)
    gl = (100, 255, 100, 255)
    gd = (30, 140, 30, 255)
    
    # Diamond shape
    px(img, 3, 1, gc); px(img, 4, 1, gc)
    hline(img, 2, 2, 5, gc)
    hline(img, 3, 1, 6, gc)
    hline(img, 4, 1, 6, gc)
    hline(img, 5, 2, 5, gc)
    px(img, 3, 6, gc); px(img, 4, 6, gc)
    # Highlight
    px(img, 3, 2, gl); px(img, 2, 3, gl)
    # Shadow
    px(img, 5, 5, gd); px(img, 4, 5, gd)
    
    outline(img)
    return img

def make_gold_gem():
    """Gold gem - 8x8, yellow"""
    img = new(8, 8)
    gc = (255, 200, 0, 255)
    gl = (255, 240, 100, 255)
    gd = (200, 150, 0, 255)
    
    # Circular coin shape
    ellipse(img, 3, 3, 2, 2, gc)
    px(img, 3, 3, gl)  # shine
    px(img, 2, 2, gl)
    px(img, 4, 4, gd)
    # $ symbol
    px(img, 3, 2, gd); px(img, 3, 4, gd)
    
    outline(img)
    return img

def make_hp_orb():
    """HP orb - 10x10, red"""
    img = new(10, 10)
    rc = (220, 50, 50, 255)
    rl = (255, 120, 120, 255)
    rd = (160, 30, 30, 255)
    
    ellipse(img, 4, 4, 3, 3, rc)
    # Highlight
    px(img, 3, 3, rl); px(img, 4, 3, rl)
    px(img, 3, 2, rl)
    # Shadow
    px(img, 5, 5, rd); px(img, 5, 6, rd)
    # Cross/heart pattern
    px(img, 4, 3, (255, 150, 150, 255))
    
    outline(img)
    return img

def make_fire_trail():
    """Fire trail segment - 32x8, 3 frames"""
    frames = []
    for f in range(3):
        img = new(32, 8)
        intensity = 1.0 - f * 0.3
        for x in range(32):
            h = int(4 * intensity * (1 + 0.3 * math.sin(x * 0.5 + f)))
            for y in range(8 - h, 8):
                t = (y - (8 - h)) / max(1, h)
                r = int(255 * intensity)
                g = int((200 - 150 * t) * intensity)
                b = int(50 * (1 - t) * intensity)
                a = int(200 * intensity * (1 - t * 0.3))
                px(img, x, y, (r, g, b, a))
        frames.append(img)
    return frames

def make_ice_aura():
    """Ice aura effect - 48x48, semi-transparent"""
    img = new(48, 48)
    ic = (150, 210, 255, 60)
    il = (200, 235, 255, 40)
    
    # Circular aura
    for angle in range(0, 360, 5):
        rad = angle * math.pi / 180
        for r in range(18, 23):
            x = int(24 + r * math.cos(rad))
            y = int(24 + r * math.sin(rad))
            px(img, x, y, ic)
    
    # Inner glow
    for angle in range(0, 360, 8):
        rad = angle * math.pi / 180
        for r in range(15, 19):
            x = int(24 + r * math.cos(rad))
            y = int(24 + r * math.sin(rad))
            px(img, x, y, il)
    
    # Snowflake particles
    for i in range(6):
        angle = i * 60 * math.pi / 180
        x = int(24 + 20 * math.cos(angle))
        y = int(24 + 20 * math.sin(angle))
        px(img, x, y, (255, 255, 255, 100))
    
    return img

def make_rune_flash():
    """Rune crit flash - 24x24"""
    img = new(24, 24)
    rc = (100, 140, 255, 200)
    rl = (180, 200, 255, 150)
    
    # Rune circle
    for angle in range(0, 360, 10):
        rad = angle * math.pi / 180
        x = int(12 + 9 * math.cos(rad))
        y = int(12 + 9 * math.sin(rad))
        px(img, x, y, rc)
    
    # Rune symbols (simple geometric)
    # Triangle
    px(img, 12, 4, rl)
    px(img, 8, 10, rl); px(img, 16, 10, rl)
    hline(img, 10, 8, 16, rl)
    vline(img, 12, 4, 10, rl)
    # Cross
    hline(img, 16, 9, 15, rl)
    vline(img, 12, 14, 19, rl)
    
    return img


def generate_effects():
    print("\n✨ Generating Effects...")
    save(make_xp_gem(), 'effects', 'xp_gem.png')
    save(make_gold_gem(), 'effects', 'gold_gem.png')
    save(make_hp_orb(), 'effects', 'hp_orb.png')
    save(make_ice_aura(), 'effects', 'ice_aura.png')
    save(make_rune_flash(), 'effects', 'rune_flash.png')
    
    fire_frames = make_fire_trail()
    for i, f in enumerate(fire_frames):
        save(f, 'effects', f'fire_trail_{i+1}.png')


# ============================================================
# UI ICONS (16x16)
# ============================================================

def make_icon(draw_fn):
    img = new(16, 16)
    draw_fn(img)
    outline(img)
    return img

def icon_magic_wand(img):
    # Wand diagonal
    for i in range(10):
        px(img, 3+i, 12-i, BROWN)
        px(img, 4+i, 12-i, LBROWN)
    # Star at tip
    px(img, 12, 3, GOLD); px(img, 13, 2, GOLD)
    px(img, 14, 3, GOLD); px(img, 13, 4, GOLD)
    px(img, 13, 3, YELLOW)

def icon_knife(img):
    # Blade
    for i in range(8):
        px(img, 7+i, 2+i, LGRAY)
        px(img, 8+i, 2+i, WHT)
    # Handle
    for i in range(4):
        px(img, 4+i, 9+i, DBROWN)
        px(img, 3+i, 9+i, BROWN)
    # Guard
    px(img, 6, 8, GRAY); px(img, 7, 9, GRAY)

def icon_lightning(img):
    # Bolt shape
    bolt = [(8,1),(7,2),(8,3),(7,4),(8,5),(6,6),(7,6),(8,6),(9,7),(8,8),(9,9),(8,10),(7,11),(8,12),(7,13)]
    for x, y in bolt:
        px(img, x, y, YELLOW)
        px(img, x-1, y, GOLD)
    # Glow
    px(img, 8, 6, (255,255,200,255))

def icon_holy_water(img):
    # Bottle
    rect(img, 6, 3, 4, 2, LGRAY)  # neck
    rect(img, 5, 5, 6, 7, BLUE)   # body
    rect(img, 6, 5, 4, 7, lit(BLUE))  # liquid highlight
    # Cap
    rect(img, 6, 2, 4, 1, GRAY)
    # Cross
    px(img, 8, 7, WHT); px(img, 7, 8, WHT)
    px(img, 8, 8, WHT); px(img, 9, 8, WHT)
    px(img, 8, 9, WHT)

def icon_fireball(img):
    # Fire circle
    ellipse(img, 8, 8, 5, 5, ORANGE)
    ellipse(img, 8, 7, 3, 3, YELLOW)
    px(img, 8, 7, (255, 255, 200, 255))
    # Flame tips
    px(img, 8, 2, ORANGE); px(img, 6, 3, ORANGE)
    px(img, 10, 3, ORANGE); px(img, 8, 3, YELLOW)

def icon_bone_shield(img):
    # Shield shape
    rect(img, 4, 2, 8, 8, BONE)
    hline(img, 10, 5, 10, BONE)
    hline(img, 11, 6, 9, BONE)
    px(img, 7, 12, BONE); px(img, 8, 12, BONE)
    # Skull emblem
    rect(img, 6, 4, 4, 3, DBONE)
    px(img, 6, 4, BLK); px(img, 9, 4, BLK)
    hline(img, 6, 6, 9, BLK)

def icon_speed(img):
    # Arrow/chevron
    for i in range(5):
        px(img, 4+i, 8-i, TEAL)
        px(img, 4+i, 8+i, TEAL)
    for i in range(5):
        px(img, 7+i, 8-i, lit(TEAL))
        px(img, 7+i, 8+i, lit(TEAL))

def icon_damage(img):
    # Sword
    vline(img, 8, 1, 10, LGRAY)
    vline(img, 7, 1, 10, WHT)
    # Guard
    hline(img, 10, 5, 10, GOLD)
    # Handle
    vline(img, 7, 11, 14, BROWN)
    vline(img, 8, 11, 14, DBROWN)
    # Pommel
    px(img, 7, 14, GOLD); px(img, 8, 14, GOLD)

def icon_hp(img):
    # Heart
    rect(img, 3, 5, 4, 4, RED)
    rect(img, 9, 5, 4, 4, RED)
    rect(img, 5, 7, 6, 4, RED)
    rect(img, 6, 11, 4, 1, RED)
    px(img, 7, 12, RED); px(img, 8, 12, RED)
    # Highlight
    px(img, 4, 5, lit(RED)); px(img, 10, 5, lit(RED))

def icon_regen(img):
    # Green cross
    rect(img, 6, 3, 4, 10, GREEN)
    rect(img, 3, 6, 10, 4, GREEN)
    # Plus shine
    px(img, 7, 4, LGREEN); px(img, 4, 7, LGREEN)

def icon_pickup(img):
    # Magnet shape
    rect(img, 3, 3, 3, 8, RED)
    rect(img, 10, 3, 3, 8, BLUE)
    rect(img, 6, 3, 4, 3, LGRAY)
    # Arc
    hline(img, 10, 5, 11, (150,150,160,255))
    px(img, 4, 11, RED); px(img, 11, 11, BLUE)

def icon_projectile(img):
    # +1 projectile
    # Arrow pointing up
    px(img, 7, 3, GOLD); px(img, 8, 3, GOLD)
    px(img, 6, 4, GOLD); px(img, 9, 4, GOLD)
    px(img, 5, 5, GOLD); px(img, 10, 5, GOLD)
    rect(img, 7, 5, 2, 6, GOLD)
    # Plus symbol
    px(img, 12, 11, WHT); px(img, 13, 10, WHT)
    px(img, 13, 11, WHT); px(img, 13, 12, WHT)
    px(img, 14, 11, WHT)

def icon_kills(img):
    # Skull (small)
    rect(img, 4, 3, 8, 6, BONE)
    rect(img, 5, 2, 6, 1, BONE)
    rect(img, 5, 5, 2, 2, BLK)
    rect(img, 9, 5, 2, 2, BLK)
    px(img, 7, 7, DBONE); px(img, 8, 7, DBONE)
    hline(img, 9, 5, 10, DBONE)
    px(img, 6, 10, BONE); px(img, 8, 10, BONE); px(img, 10, 10, BONE)

def icon_time(img):
    # Clock
    ellipse(img, 8, 8, 5, 5, LGRAY)
    ellipse(img, 8, 8, 4, 4, (220, 220, 230, 255))
    # Hands
    vline(img, 8, 5, 8, BLK)
    hline(img, 8, 8, 11, BLK)
    # Numbers
    px(img, 8, 4, BLK); px(img, 12, 8, BLK)
    px(img, 8, 12, BLK); px(img, 4, 8, BLK)

def icon_wave(img):
    # Star/badge
    for i in range(5):
        angle = (i * 72 - 90) * math.pi / 180
        x = int(8 + 5 * math.cos(angle))
        y = int(8 + 5 * math.sin(angle))
        px(img, x, y, GOLD)
        px(img, x, y-1 if y > 1 else y, GOLD)
    ellipse(img, 8, 8, 3, 3, GOLD)
    ellipse(img, 8, 8, 2, 2, YELLOW)

def icon_gold(img):
    # Coin
    ellipse(img, 8, 8, 5, 5, GOLD)
    ellipse(img, 8, 8, 4, 4, YELLOW)
    ellipse(img, 8, 8, 3, 3, GOLD)
    # $ symbol
    vline(img, 8, 5, 11, (180, 140, 0, 255))
    hline(img, 7, 6, 9, (180, 140, 0, 255))
    hline(img, 9, 7, 10, (180, 140, 0, 255))


def generate_ui():
    print("\n🎮 Generating UI Icons...")
    # Weapon icons
    save(make_icon(icon_magic_wand), 'ui', 'icon_magic_wand.png')
    save(make_icon(icon_knife), 'ui', 'icon_knife.png')
    save(make_icon(icon_lightning), 'ui', 'icon_lightning.png')
    save(make_icon(icon_holy_water), 'ui', 'icon_holy_water.png')
    save(make_icon(icon_fireball), 'ui', 'icon_fireball.png')
    save(make_icon(icon_bone_shield), 'ui', 'icon_bone_shield.png')
    
    # Bonus icons
    save(make_icon(icon_speed), 'ui', 'icon_speed.png')
    save(make_icon(icon_damage), 'ui', 'icon_damage.png')
    save(make_icon(icon_hp), 'ui', 'icon_hp.png')
    save(make_icon(icon_regen), 'ui', 'icon_regen.png')
    save(make_icon(icon_pickup), 'ui', 'icon_pickup.png')
    save(make_icon(icon_projectile), 'ui', 'icon_projectile.png')
    
    # Stat icons
    save(make_icon(icon_kills), 'ui', 'icon_kills.png')
    save(make_icon(icon_time), 'ui', 'icon_time.png')
    save(make_icon(icon_wave), 'ui', 'icon_wave.png')
    save(make_icon(icon_gold), 'ui', 'icon_gold.png')


# ============================================================
# PREVIEW SHEET
# ============================================================

def generate_preview():
    """Create a single image showing all sprites for quick reference"""
    print("\n📋 Generating Preview Sheet...")
    
    img = Image.new('RGBA', (800, 900), (30, 25, 40, 255))
    draw = ImageDraw.Draw(img)
    
    y_offset = 10
    
    # Load and paste all character sprites
    chars = ['ignis', 'gleisha', 'vitalis', 'umbra', 'archon', 'nektra', 'lumen', 'runika']
    x = 10
    for name in chars:
        fp = os.path.join(OUT, 'characters', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            # Scale up 3x for visibility
            scaled = sprite.resize((96, 96), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += 100
    
    y_offset += 110
    
    # Mobs
    mobs = ['skeleton', 'zombie', 'bat', 'ghost', 'spider', 'dark_mage']
    x = 10
    for name in mobs:
        fp = os.path.join(OUT, 'mobs', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((sprite.width*3, sprite.height*3), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += max(scaled.width + 10, 80)
    
    y_offset += 100
    
    # Boss mobs
    bosses = ['golem', 'necromorph']
    x = 10
    for name in bosses:
        fp = os.path.join(OUT, 'mobs', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((sprite.width*2, sprite.height*2), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += scaled.width + 20
    
    y_offset += 120
    
    # Tiles
    x = 10
    for name in ['floor_stone_1', 'floor_stone_2', 'floor_stone_3', 'floor_stone_4', 'floor_stone_moss', 'floor_stone_wet']:
        fp = os.path.join(OUT, 'tiles', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((64, 64), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += 74
    
    y_offset += 80
    
    # Decorations
    decos = ['barrel', 'barrel_cobweb', 'barrel_broken', 'skull', 'coffin', 'column', 'table']
    x = 10
    for name in decos:
        fp = os.path.join(OUT, 'decorations', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((sprite.width*2, sprite.height*2), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += scaled.width + 15
    
    y_offset += 110
    
    # Overlay decorations
    decos2 = ['cracks_1', 'cracks_2', 'cracks_3', 'puddle_water', 'puddle_poison', 'moss_1', 'cobweb']
    x = 10
    for name in decos2:
        fp = os.path.join(OUT, 'decorations', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            # Show on a dark bg for visibility
            bg = Image.new('RGBA', (64, 64), (45, 42, 55, 255))
            s2 = sprite.resize((64, 64), Image.NEAREST)
            bg.paste(s2, (0, 0), s2)
            img.paste(bg, (x, y_offset))
            x += 74
    
    y_offset += 80
    
    # Effects
    effects = ['xp_gem', 'gold_gem', 'hp_orb']
    x = 10
    for name in effects:
        fp = os.path.join(OUT, 'effects', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((sprite.width*4, sprite.height*4), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += scaled.width + 15
    
    # Torch frames
    x += 30
    for i in range(1, 5):
        fp = os.path.join(OUT, 'decorations', f'torch_{i}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((sprite.width*2, sprite.height*2), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += scaled.width + 5
    
    y_offset += 80
    
    # UI icons
    icons = ['icon_magic_wand', 'icon_knife', 'icon_lightning', 'icon_holy_water',
             'icon_fireball', 'icon_bone_shield', 'icon_speed', 'icon_damage',
             'icon_hp', 'icon_regen', 'icon_pickup', 'icon_projectile',
             'icon_kills', 'icon_time', 'icon_wave', 'icon_gold']
    x = 10
    for name in icons:
        fp = os.path.join(OUT, 'ui', f'{name}.png')
        if os.path.exists(fp):
            sprite = Image.open(fp)
            scaled = sprite.resize((48, 48), Image.NEAREST)
            img.paste(scaled, (x, y_offset), scaled)
            x += 50
            if x > 780:
                x = 10
                y_offset += 55
    
    save(img, 'PREVIEW_ALL_SPRITES.png')


# ============================================================
# MAIN
# ============================================================

if __name__ == '__main__':
    print("🎨 Magic Baser Sprite Generator")
    print("=" * 40)
    
    generate_wizards()
    generate_mobs()
    generate_tiles()
    generate_decorations()
    generate_effects()
    generate_ui()
    generate_preview()
    
    # Count files
    total = 0
    for root, dirs, files in os.walk(OUT):
        total += len([f for f in files if f.endswith('.png')])
    
    print(f"\n{'=' * 40}")
    print(f"✅ Done! Generated {total} sprite files")
    print(f"📁 Output: {OUT}/")
